import { restoreAccount, type AccountSecret } from '../arkade/account.ts';
import { loadAddresses, type AccountAddresses } from '../arkade/addresses.ts';
import { loadBalance, type BalanceAmounts } from '../arkade/balance.ts';
import { createGameWalletStorage, type GameWalletStorage } from './game-wallet-storage.ts';

export type BisGameWalletState = Readonly<{
  status: 'loading' | 'empty' | 'ready' | 'unavailable';
  profileId?: string; addresses?: AccountAddresses; balance?: BalanceAmounts; message?: string;
}>;
export function createBisGameWallet(options: { playerProfileId(): string | undefined }, dependencies = {
  storage: createGameWalletStorage(), restore: restoreAccount, addresses: loadAddresses, balance: loadBalance,
}) {
  const storage: GameWalletStorage = dependencies.storage;
  let state: BisGameWalletState = Object.freeze({status:'loading'});
  let operation = new AbortController(), disposed = false, importing = false, refreshQueued = false;
  const listeners = new Set<() => void>();
  const publish = (next: BisGameWalletState) => { if (!disposed) { state = Object.freeze(next); listeners.forEach(l => l()); } };
  const begin = () => { operation.abort(); operation = new AbortController(); return operation.signal; };
  async function inspect(account: AccountSecret | null, signal: AbortSignal) {
    if (signal.aborted || disposed) return;
    if (!account) { publish({status:'empty'}); return; }
    publish({status:'loading', profileId:account.profileId});
    const [addresses, balance] = await Promise.allSettled([dependencies.addresses(account, signal), dependencies.balance(account, signal)]);
    if (signal.aborted || disposed) return;
    publish({status: addresses.status === 'fulfilled' && balance.status === 'fulfilled' ? 'ready' : 'unavailable', profileId:account.profileId,
      ...(addresses.status === 'fulfilled' ? {addresses:addresses.value} : {}),
      ...(balance.status === 'fulfilled' ? {balance:balance.value} : {}),
      ...(addresses.status === 'rejected' || balance.status === 'rejected' ? {message:'Game wallet reads unavailable. Refresh to retry.'} : {})});
  }
  async function refresh() {
    if (disposed) return;
    if (importing) { refreshQueued = true; return; }
    const signal = begin(); publish({status:'loading'});
    try { await inspect(await storage.load(), signal); }
    catch { if (!signal.aborted) publish({status:'unavailable', message:'Game wallet storage unavailable. Refresh to retry.'}); }
  }
  const unsubscribe = storage.subscribe(() => { void refresh(); });
  void refresh();
  return {
    getState: () => state,
    subscribe(listener: () => void) { listeners.add(listener); return () => { listeners.delete(listener); }; },
    refresh,
    async importWallet(phrase: string) {
      if (disposed || importing) return false;
      importing = true; const previous = state, signal = begin(); publish({...previous, status:'loading', message:undefined});
      try {
        const account = await dependencies.restore(phrase, signal);
        signal.throwIfAborted();
        if (account.profileId === options.playerProfileId()) throw Error();
        await storage.select(account);
        await inspect(account, signal);
        return true;
      } catch {
        if (!signal.aborted) publish({...previous, message:'Import failed. Check the recovery phrase, connection, and use a wallet different from the player.'});
        return false;
      } finally { importing = false; if (refreshQueued) { refreshQueued = false; void refresh(); } }
    },
    dispose() { disposed = true; operation.abort(); unsubscribe(); storage.dispose(); listeners.clear(); },
  };
}

