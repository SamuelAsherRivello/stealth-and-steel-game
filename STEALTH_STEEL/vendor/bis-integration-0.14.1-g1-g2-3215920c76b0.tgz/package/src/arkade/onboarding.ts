import {Wallet,ReadonlyWallet,MnemonicIdentity,RestArkProvider,RestIndexerProvider,InMemoryWalletRepository,InMemoryContractRepository,ArkAddress,CSVMultisigTapscript,hasBoardingTxExpired,Transaction,type SettleParams} from '@arkade-os/sdk';
import {SIGNET_OPERATOR,requireSignet,type AccountSecret} from './account.ts';
import {walletReservations,eligibleUnreservedCoins} from '../core/wallet-reservations.ts';
import {readOnboardingRecord,type OnboardingRecord,type OnboardingCoin,type OnboardingScope} from '../core/onboarding-record.ts';
import {onboardingFailure,type OnboardingAdapter,type OnboardingFacts,type OnboardingTransaction} from '../core/onboarding-service.ts';
import {onboardingStream} from '../core/onboarding-stream.ts';
import {settlementTimeoutMs} from '../core/boarding-status.ts';
import {withBrowserMutation} from '../core/logout-cleanup.ts';
const hex=(value:Uint8Array)=>Array.from(value,b=>b.toString(16).padStart(2,'0')).join('');
const plain=({txid,vout,value}:OnboardingCoin)=>({txid,vout,value});
const point=(c:{txid:string;vout:number})=>`${c.txid}:${c.vout}`;
const sum=(items:{value:number}[])=>items.reduce((s,c)=>s+c.value,0);
export const onboardingScope=(profileId:string):OnboardingScope=>({profileId,network:'signet',operator:SIGNET_OPERATOR});
function options(provider:RestArkProvider){return {arkProvider:provider,indexerProvider:new RestIndexerProvider(SIGNET_OPERATOR),settlementConfig:false as const,storage:{walletRepository:new InMemoryWalletRepository(),contractRepository:new InMemoryContractRepository()}};}
async function bounded<T>(work:Promise<T>,signal:AbortSignal,ms=30000):Promise<T>{
  const stop=AbortSignal.any([signal,AbortSignal.timeout(ms)]);stop.throwIfAborted();let abort:()=>void=()=>{};
  try{return await Promise.race([work,new Promise<never>((_,reject)=>{abort=()=>reject(Error('Onboarding connection deadline exceeded.'));stop.addEventListener('abort',abort,{once:true});})]);}
  finally{stop.removeEventListener('abort',abort);}
}
async function readFacts(wallet:ReadonlyWallet,provider:RestArkProvider,scope:OnboardingScope,r:OnboardingRecord|undefined,signal:AbortSignal):Promise<OnboardingFacts>{
  const [info,coins,receipts,tip,address,own]=await bounded(Promise.all([provider.getInfo(),wallet.getBoardingUtxos(),wallet.getSpendableVtxos({withRecoverable:false,withUnrolled:false}),wallet.onchainProvider.getChainTip(),wallet.getBoardingAddress(),wallet.getAddress()]),signal);
  requireSignet(info.network);const live=wallet.getProviderConnectionState();if(live.mode!=='online'||live.source!=='live')throw Error('Live connection unavailable.');
  const txs=await bounded(wallet.onchainProvider.getTransactions(address),signal);
  const bitcoinScript=hex(wallet.boardingTapscript.pkScript),arkadeScript=hex(ArkAddress.decode(own).pkScript);
  const allReservations=walletReservations(scope.profileId),other=allReservations.filter(v=>v.id!==`onboarding:${r?.id}`);
  const allowed=new Set(eligibleUnreservedCoins([...coins,...receipts],other).map(point));
  const exit=CSVMultisigTapscript.decode(Uint8Array.from(wallet.boardingTapscript.exitScript.match(/.{2}/g)!,v=>parseInt(v,16)));
  const snapshot={...scope,complete:true,unresolvedOnboarding:false,bitcoinScript,arkadeScript,
    boarding:coins.map(c=>({...plain(c),confirmed:c.status.confirmed,expired:hasBoardingTxExpired(c,exit.params.timelock,tip.height),reserved:!allowed.has(point(c))})),
    spendable:receipts.map(c=>({...plain(c),confirmed:true,expired:false,reserved:!allowed.has(point(c))})),
    policy:{zeroFees:info.fees.txFeeRate==='0'&&Object.values(info.fees.intentFee).every(v=>v===''||v==='0'),arkadeMinimum:Math.max(1,Number(info.vtxoMinAmount),Number(wallet.dustAmount)),bitcoinMinimum:Math.max(1,Number(info.utxoMinAmount)),arkadeMaximum:Number(info.vtxoMaxAmount),bitcoinMaximum:Number(info.utxoMaxAmount)}};
  const transactions:OnboardingTransaction[]=txs.filter(tx=>tx.vout.some(o=>o.scriptpubkey_address===address)).map(tx=>({txid:tx.txid,confirmed:tx.status.confirmed,value:tx.vout.filter(o=>o.scriptpubkey_address===address).reduce((s,o)=>s+Number(o.value),0),kind:tx.txid===r?.returning?.commitmentTxid?'return':'incoming'}));
  let next=r;const independent:OnboardingCoin[]=[];
  if(r?.plan&&r.status==='pending'){
    // First-leg evidence binds Bitcoin inputs and the owned output script, not a balance delta.
    if(r.boarding.phase!=='receipt-verified')for(const tx of txs){
      if(r.boarding.commitmentTxid&&r.boarding.commitmentTxid!==tx.txid)continue;
      if(!r.plan.inputs.every(i=>tx.vin?.some(v=>v.txid===i.txid&&v.vout===i.vout)))continue;
      const owned=receipts.filter(c=>c.commitmentTxIds?.includes(tx.txid)&&c.script===r.plan!.arkadeScript);
      if(sum(owned)!==r.plan.totalSats||owned.some(c=>c.assets?.length))continue;
      next={...r,boarding:{...r.boarding,phase:'receipt-verified',commitmentTxid:tx.txid,receipts:owned.map(plain),verifiedAt:Date.now()}};break;
    }
    if(next?.plan&&next.boarding.phase==='receipt-verified'&&next.returning.inputs.length){
      const consumed=(await bounded(wallet.indexerProvider.getVtxos({outpoints:next.returning.inputs.map(({txid,vout})=>({txid,vout}))}),signal)).vtxos;
      const commitment=consumed[0]?.settledBy;
      if(commitment&&next.returning.inputs.every(i=>consumed.some(c=>point(c)===point(i)&&c.value===i.value&&c.settledBy===commitment))){
        const tx=txs.find(t=>t.txid===commitment),owned=receipts.filter(c=>c.commitmentTxIds?.includes(commitment)&&c.script===next!.plan!.arkadeScript);
        if(tx&&sum(owned)===next.plan.targetSats&&!owned.some(c=>c.assets?.length)&&tx.vout.filter(o=>o.scriptpubkey_address===address).reduce((s,o)=>s+Number(o.value),0)===next.plan.returnSats)
          next={...next,status:'complete',completedAt:Date.now(),returning:{...next.returning,phase:'receipt-verified',commitmentTxid:commitment,receipts:owned.map(plain),verifiedAt:Date.now()},progress:{stage:'complete',at:Date.now()}};
      }
    }
    const frozen=new Set(r.plan.inputs.map(point));
    independent.push(...coins.filter(c=>!frozen.has(point(c))).map(plain));
    // A receipt from another commitment is independent only when its funding
    // ancestry can be inspected and excludes every frozen boarding input.
    for(const c of receipts){
      if((r.independent??[]).some(i=>point(i)===point(c))){independent.push(plain(c));continue;}
      if(next?.boarding?.receipts?.some(i=>point(i)===point(c)))continue;
      if(!c.commitmentTxIds?.length||c.commitmentTxIds.some(id=>id===next?.boarding?.commitmentTxid||id===next?.returning?.commitmentTxid))continue;
      let independentProof=true;
      for(const id of c.commitmentTxIds){
        try{const raw=await bounded(wallet.onchainProvider.getRawTransaction(id),signal);const tx=Transaction.fromRaw(raw);
          for(let i=0;i<tx.inputsLength;i++){const input=tx.getInput(i);if(input.txid&&frozen.has(`${hex(input.txid)}:${input.index}`))independentProof=false;}}
        catch{independentProof=false;}
      }
      if(independentProof)independent.push(plain(c));
    }
  }else independent.push(...coins.map(plain),...receipts.map(plain));
  for(const [kind,leg] of [['boarding',next?.boarding],['return',next?.returning]] as const){if(!leg?.commitmentTxid)continue;const tx=txs.find(t=>t.txid===leg.commitmentTxid);const existing=transactions.find(t=>t.txid===leg.commitmentTxid);if(existing)existing.kind=kind;else if(tx)transactions.push({txid:tx.txid,kind,confirmed:tx.status.confirmed,value:kind==='boarding'?next!.plan!.totalSats:next!.plan!.returnSats});}
  return {snapshot,address,transactions,independent:[...new Map(independent.map(c=>[point(c),c])).values()],...(next&&next!==r?{reconciled:next}:{})};
}
export function createOnboardingAdapter(account:AccountSecret,isCurrent:()=>boolean):OnboardingAdapter{
  const scope=onboardingScope(account.profileId);
  const current=(signal:AbortSignal)=>{signal.throwIfAborted();if(!isCurrent())throw Error('Onboarding account changed.');};
  return {
    async inspect(record,signal){
      const provider=new RestArkProvider(SIGNET_OPERATOR);let wallet:ReadonlyWallet|undefined;
      const acquiring=ReadonlyWallet.create({...options(provider),identity:await MnemonicIdentity.fromMnemonic(account.phrase,{isMainnet:false}).toReadonly()});
      try{wallet=await bounded(acquiring,signal);current(signal);return await readFacts(wallet,provider,scope,record,signal);}
      finally{if(wallet)await bounded(wallet.dispose(),signal).catch(()=>{});else void acquiring.then(w=>w.dispose()).catch(()=>{});}
    },
    async submit(original,which,signal,checkpoint){
      if(!navigator.locks)throw Error('Onboarding lock unavailable.');
      await navigator.locks.request(`bis-onboarding-signer:${account.profileId}`,{ifAvailable:true},async lease=>{
        if(!lease)return;
        await withBrowserMutation(async()=>{
          let wallet:Wallet|undefined;const stop=new AbortController(),active=AbortSignal.any([signal,stop.signal]);const provider=new RestArkProvider(SIGNET_OPERATOR);let hash:string|undefined,open=true,deadline=Date.now()+300000;
          const assert=()=>{current(active);if(!open||Date.now()>=deadline)throw Error('Onboarding signing deadline exceeded.');};
          const progress=async(stage:NonNullable<OnboardingRecord['progress']>['stage'])=>{assert();await checkpoint(r=>r.status==='pending'?{...r,progress:{stage,at:Date.now(),...(r.progress?.failure?{failure:r.progress.failure}:{})}}:r);};
          const register=provider.registerIntent.bind(provider);
          provider.registerIntent=async intent=>{
            assert();await checkpoint(r=>{if(!r.plan||r.id!==original.id||r[which].phase!=='prepared')throw Error('Onboarding registration already attempted.');return {...r,[which]:{...r[which],phase:'submitting',startedAt:Date.now()}};});
            assert();let id:string;
            try{id=await register(intent);}catch(error){throw Object.assign(Error('Onboarding registration outcome unknown.'),{cause:undefined});}
            await checkpoint(r=>{if(!r.plan||r.id!==original.id)throw Error('Onboarding account changed.');return {...r,[which]:{...r[which],phase:'registered',intentId:id,registeredAt:Date.now()},progress:{stage:'registered',at:Date.now()}};});
            hash=hex(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(id))));return id;
          };
          provider.deleteIntent=async()=>{throw Error('Automatic intent deletion is disabled; reconcile registration.');};
          const stream=provider.getEventStream.bind(provider);
          provider.getEventStream=(s,topics)=>onboardingStream(a=>stream(a,topics),AbortSignal.any([s,active]),()=>hash,Math.min(300000,Math.max(10000,deadline-Date.now())),Math.max(1,deadline-Date.now()),()=>{});
          const confirm=provider.confirmRegistration.bind(provider);provider.confirmRegistration=async id=>{assert();if(readOnboardingRecord(scope)?.[which]?.intentId!==id)throw Error('Onboarding registration changed.');await confirm(id);await progress('participating');};
          const nonces=provider.submitTreeNonces.bind(provider);provider.submitTreeNonces=async(...args)=>{assert();await nonces(...args);await progress('signing');};
          const signatures=provider.submitTreeSignatures.bind(provider);provider.submitTreeSignatures=async(...args)=>{assert();await signatures(...args);await progress('signing');};
          const forfeits=provider.submitSignedForfeitTxs.bind(provider);provider.submitSignedForfeitTxs=async(...args)=>{assert();await forfeits(...args);await progress('signing');};
          let acquisition:Promise<Wallet>|undefined;
          try{
            const info=await bounded(provider.getInfo(),active);requireSignet(info.network);deadline=Date.now()+settlementTimeoutMs(info);
            acquisition=Wallet.create({...options(provider),identity:MnemonicIdentity.fromMnemonic(account.phrase,{isMainnet:false})});wallet=await bounded(acquisition,active);assert();
            const r=readOnboardingRecord(scope);if(!r?.plan||r.id!==original.id||r[which].phase!=='prepared')return;
            const facts=await readFacts(wallet,provider,scope,r,active),p=r.plan,policy=facts.snapshot.policy;
            if(!policy.zeroFees||p.targetSats<policy.arkadeMinimum||p.returnSats<policy.bitcoinMinimum||policy.arkadeMaximum>0&&p.totalSats>policy.arkadeMaximum||policy.bitcoinMaximum>0&&p.returnSats>policy.bitcoinMaximum||p.bitcoinScript!==facts.snapshot.bitcoinScript||p.arkadeScript!==facts.snapshot.arkadeScript)throw Error('Onboarding terms changed.');
            const candidates=which==='boarding'?await bounded(wallet.getBoardingUtxos(),active):await bounded(wallet.getSpendableVtxos({withRecoverable:false,withUnrolled:false}),active);
            const eligible=new Set(eligibleUnreservedCoins(candidates,walletReservations(account.profileId).filter(o=>o.id!==`onboarding:${r.id}`)).map(point));
            const selected=r[which].inputs.map(i=>candidates.find(c=>point(c)===point(i)&&c.value===i.value&&eligible.has(point(c))));
            if(selected.some(c=>!c)||which==='boarding'&&r.plan.inputs.some(i=>!facts.snapshot.boarding.some(c=>point(c)===point(i)&&c.confirmed&&!c.expired&&!c.reserved))){
              if(which==='boarding')await checkpoint(v=>v.plan&&v.boarding.phase==='prepared'?{...v,status:'not-submitted'}:v);
              throw Error('Onboarding inputs changed.');
            }
            const own=await wallet.getAddress(),address=await wallet.getBoardingAddress();
            const params:SettleParams={inputs:selected as SettleParams['inputs'],outputs:which==='boarding'?[{address:own,amount:BigInt(p.totalSats)}]:[{address,amount:BigInt(p.returnSats)},{address:own,amount:BigInt(p.targetSats)}]};
            // The SDK builds/signs the exact constrained input/output intent.
            const commitment=await wallet.settle(params,async event=>{if(event.type==='batch_failed')throw Error('Selected onboarding batch failed.');});
            await checkpoint(v=>v.plan&&v.id===r.id?{...v,[which]:{...v[which],commitmentTxid:commitment},progress:{stage:'broadcast',at:Date.now()}}:v);
          }catch(error){
            if(!signal.aborted&&isCurrent())await checkpoint(r=>r.status==='pending'?{...r,interrupted:true,progress:{stage:r.progress?.stage??'checking',at:Date.now(),failure:onboardingFailure(error),failures:(r.progress?.failures??0)+1,retryAt:Date.now()+Math.min(60000,5000*2**Math.min(r.progress?.failures??0,4))}}:r);
          }finally{
            open=false;stop.abort();
            // Keep signer ownership until actual SDK cleanup ends, including a late acquisition.
            if(wallet)await wallet.dispose();else if(acquisition)await acquisition.then(w=>w.dispose()).catch(()=>{});
          }
        });
      });
    }
  };
}
