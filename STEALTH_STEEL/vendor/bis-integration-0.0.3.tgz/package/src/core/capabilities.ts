import type { BisState } from './context.ts';

/** The game-facing item capability deliberately does not inspect the Game Wallet. */
export function itemSupportAvailable(state: Pick<BisState, 'phase' | 'hasProfile'>, environment: { navigator?: { locks?: unknown } } = globalThis): boolean {
  return state.phase === 'active' && state.hasProfile && !!environment.navigator?.locks;
}
