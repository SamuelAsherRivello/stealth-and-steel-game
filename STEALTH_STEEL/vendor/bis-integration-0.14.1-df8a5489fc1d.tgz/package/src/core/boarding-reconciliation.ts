import type { BoardingRecord } from './boarding-record.ts';
import { boardingAssets } from './boarding-assets.ts';

type Transaction = {txid:string;status:{confirmed:boolean};vin?:{txid:string;vout:number}[];vout:{scriptpubkey_address?:string;value:string|number}[]};
type Receipt = {value:number;commitmentTxIds?:string[];script?:string;assets?:{assetId:string;amount:bigint}[]};
type Consumed = {txid:string;vout:number;isSpent?:boolean;settledBy?:string};
export function verifiedBoardingCommitment(record:BoardingRecord, transactions:Transaction[], receipts:Receipt[], consumed:Consumed[]=[]) {
  for(const tx of transactions) {
    if(!tx.status.confirmed || (record.commitmentTxid && record.commitmentTxid!==tx.txid))continue;
    const boarding=record.quote.direction==='to-arkade';
    if(!record.inputs.every(i=>boarding ? tx.vin?.some(v=>v.txid===i.txid&&v.vout===i.vout) : consumed.some(v=>v.txid===i.txid&&v.vout===i.vout&&v.isSpent&&v.settledBy===tx.txid)))continue;
    const owned=receipts.filter(v=>v.commitmentTxIds?.includes(tx.txid));
    const values=owned.map(v=>v.value), inputSats=record.quote.inputSats??record.quote.maxSats;
    if(!values.every(v=>Number.isSafeInteger(v)&&v>=0) || values.reduce((a,b)=>a+b,0)!==(boarding?record.quote.netSats:inputSats-record.quote.amountSats))continue;
    if(record.assetChange) {
      const expected=record.assetChange;
      try {
        if(owned.length!==1 || owned[0].script!==expected.script || owned[0].value!==expected.sats ||
           JSON.stringify(boardingAssets(owned))!==JSON.stringify([...expected.assets].sort((a,b)=>a.assetId.localeCompare(b.assetId))))continue;
      } catch {continue;}
    }
    const change=tx.vout.filter(o=>o.scriptpubkey_address===record.bitcoinAddress).map(o=>Number(o.value));
    if(!change.every(v=>Number.isSafeInteger(v)&&v>=0) || change.reduce((a,b)=>a+b,0)!==(boarding?inputSats-record.quote.amountSats:record.quote.netSats))continue;
    return tx.txid;
  }
}

